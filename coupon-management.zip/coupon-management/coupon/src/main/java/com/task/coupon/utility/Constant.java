package com.task.coupon.utility;

public class Constant {

    public static final String CART_WISE = "Cart-wise";

    public static final String PRODUCT_WISE= "product-wise";

    public static final String BXGY = "bxgy";
}
